#include "deplacement_objet.c"

void deplacement_tank_bas(struct TANK *tank);
void deplacement_tank_droite(struct TANK *tank);
void deplacement_tank_haut(struct TANK *tank);
void deplacement_tank_gauche(struct TANK *tank);
void effacer_map_tank(struct TANK *tank);
void remplir_map_tank(struct TANK *tank);
