#include "flux_fichier.c"

char **creer_charger_map(int nbL, int nbC, char *file_name);
void afficher_fichier(char *file_name);
void init_carrosseries();
