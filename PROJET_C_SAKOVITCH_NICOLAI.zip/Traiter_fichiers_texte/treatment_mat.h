#include "treatment_mat.c"

char ** allocation_dyn_mat(int nbL, int nbC);
void chargement_mat(int nbL, int nbC, char ** mat);
void lib_mat(int nbL, char ** mat);
void affichage_mat(int nbL, int nbC, char ** mat);
